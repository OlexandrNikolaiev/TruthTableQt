// TruthTableBuilder.h
#ifndef TRUTHTABLEBUILDER_H
#define TRUTHTABLEBUILDER_H

#include <string>
#include <QString>
#include <vector>

class TruthTableBuilder {
public:
    TruthTableBuilder();
    void setExpression(const std::string& expr);
    bool build();

    int varCount() const;
    int subexprCount() const;
    int rowCount() const;

    const std::vector<char>& getVarList() const;
    const std::vector<std::string>& getSubexprList() const;
    bool value(int row, int col) const;

private:
    std::string _infix;
    std::string _postfix;
    std::vector<char> _varList;
    std::vector<std::string> _subexpr;
    std::vector<std::vector<bool>> _tableData;

    int precedence(char op) const;
    bool applyOp(char op, bool a, bool b = false) const;
    std::string infixToPostfix(const std::string& infix);
    std::vector<char> extractVariables(const std::string& expr) const;
    bool evaluateRow(int row, std::vector<bool>& results) const;
};

#endif // TRUTHTABLEBUILDER_H
