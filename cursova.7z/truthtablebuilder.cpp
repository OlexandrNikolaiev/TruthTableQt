#include "truthtablebuilder.h"
#include <stack>
#include <set>
#include <cctype>
#include <unordered_map>

TruthTableBuilder::TruthTableBuilder() {}

void TruthTableBuilder::setExpression(const std::string& expr) {
    _infix = expr;
}

int TruthTableBuilder::precedence(char op) const {
    if (op == '!') return 3;
    if (op == '*') return 2;
    if (op == '+') return 1;
    if (op == '>' || op == '=') return 0;
    return -1;
}

bool TruthTableBuilder::applyOp(char op, bool a, bool b) const {
    switch (op) {
    case '!': return !a;
    case '*': return a && b;
    case '+': return a || b;
    case '>': return !a || b;
    case '=': return a == b;
    }
    return false;
}

std::vector<char> TruthTableBuilder::extractVariables(const std::string& expr) const {
    std::set<char> vars;
    for (char ch : expr) {
        if (std::isalnum(ch)) vars.insert(ch);
    }
    return std::vector<char>(vars.begin(), vars.end());
}

std::string TruthTableBuilder::infixToPostfix(const std::string& infix) {
    std::stack<char> ops;
    std::string output;
    std::stack<std::string> subStack;
    _subexpr.clear();

    for (char token : infix) {
        if (token == ' ') continue;
        if (std::isalnum(token)) {
            output += token;
            subStack.push(std::string(1, token));
        }
        else if (token == '(') {
            ops.push(token);
        }
        else if (token == ')') {
            while (!ops.empty() && ops.top() != '(') {
                char op = ops.top(); ops.pop();
                output += op;
                if (op == '!') {
                    auto operand = subStack.top(); subStack.pop();
                    std::string se = "!" + operand;
                    _subexpr.push_back(se);
                    subStack.push(se);
                } else {
                    auto right = subStack.top(); subStack.pop();
                    auto left  = subStack.top(); subStack.pop();
                    std::string se = "(" + left + op + right + ")";
                    _subexpr.push_back(se);
                    subStack.push(se);
                }
            }
            if (!ops.empty()) ops.pop();
        }
        else {
            while (!ops.empty() && precedence(ops.top()) >= precedence(token)) {
                char op = ops.top(); ops.pop();
                output += op;
                if (op == '!') {
                    auto operand = subStack.top(); subStack.pop();
                    std::string se = "!" + operand;
                    _subexpr.push_back(se);
                    subStack.push(se);
                } else {
                    auto right = subStack.top(); subStack.pop();
                    auto left  = subStack.top(); subStack.pop();
                    std::string se = "(" + left + op + right + ")";
                    _subexpr.push_back(se);
                    subStack.push(se);
                }
            }
            ops.push(token);
        }
    }
    while (!ops.empty()) {
        char op = ops.top(); ops.pop();
        output += op;
        if (op == '!') {
            auto operand = subStack.top(); subStack.pop();
            std::string se = "!" + operand;
            _subexpr.push_back(se);
            subStack.push(se);
        } else {
            auto right = subStack.top(); subStack.pop();
            auto left  = subStack.top(); subStack.pop();
            std::string se = left + op + right;
            _subexpr.push_back(se);
            subStack.push(se);
        }
    }
    return output;
}

bool TruthTableBuilder::evaluateRow(int row, std::vector<bool>& results) const {
    int n = _varList.size();
    for (int j = 0; j < n; ++j) {
        bool val = (row & (1 << (n - j - 1))) != 0;
        results[j] = val;
    }
    std::unordered_map<char,bool> vals;
    for (int j = 0; j < n; ++j) {
        vals[_varList[j]] = results[j];
    }
    std::stack<bool> st;
    int idx = 0;
    for (char token : _postfix) {
        if (std::isalnum(token)) {
            st.push(vals.at(token));
        } else {
            if (token == '!') {
                bool a = st.top(); st.pop();
                bool r = applyOp(token, a, false);
                st.push(r);
                results[n + idx++] = r;
            } else {
                bool b = st.top(); st.pop();
                bool a = st.top(); st.pop();
                bool r = applyOp(token, a, b);
                st.push(r);
                results[n + idx++] = r;
            }
        }
    }
    return st.top();
}

bool TruthTableBuilder::build() {
    _varList = extractVariables(_infix);
    _postfix = infixToPostfix(_infix);
    int n = _varList.size();
    int m = _subexpr.size();
    int rows = 1 << n;
    _tableData.assign(rows, std::vector<bool>(n + m, false));
    for (int i = 0; i < rows; ++i) {
        std::vector<bool> row(n + m);
        evaluateRow(i, row);
        _tableData[i] = row;
    }
    return true;
}

int TruthTableBuilder::varCount() const { return (int)_varList.size(); }
int TruthTableBuilder::subexprCount() const { return (int)_subexpr.size(); }
int TruthTableBuilder::rowCount() const { return (int)_tableData.size(); }
const std::vector<char>& TruthTableBuilder::getVarList() const { return _varList; }
const std::vector<std::string>& TruthTableBuilder::getSubexprList() const { return _subexpr; }
bool TruthTableBuilder::value(int row, int col) const { return _tableData[row][col]; }
