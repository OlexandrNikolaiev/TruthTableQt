#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QString>
#include <QMessageBox>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
    , tableBuilder(std::make_unique<TruthTableBuilder>())
{
    ui->setupUi(this);
    this->setWindowTitle("Генератор таблиць істинності");
    ui->inputLineEdit->setPlaceholderText("Введіть логічний вираз, наприклад: a+b+c+d*e");

    connect(ui->inputLineEdit, &QLineEdit::returnPressed, this, &MainWindow::on_buildButton_clicked);

    connect(ui->calculateButton, &QPushButton::clicked, this, &MainWindow::on_buildButton_clicked);
    connect(ui->clearButton, &QPushButton::clicked, this, &MainWindow::on_clearButton_clicked);

}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_buildButton_clicked()
{
    QString expr = ui->inputLineEdit->text();
    if(expr.isEmpty()){
        QMessageBox::warning(this, "Помилка", "Ви не ввели логічний вираз!");
        return;
    }

    tableBuilder->setExpression(expr.toStdString());
    if (!tableBuilder->build()) {
        QMessageBox::critical(this, "Помилка", "Не вдалося побудувати таблицю істинності.");
        return;
    }

    int variables = tableBuilder->varCount();
    int subexpressions = tableBuilder->subexprCount();
    int rows = tableBuilder->rowCount();
    int cols = variables + subexpressions;
    ui->truthTable->clear();
    ui->truthTable->setRowCount(rows);
    ui->truthTable->setColumnCount(cols);
    QStringList headers;
    for (char var : tableBuilder->getVarList())
        headers << QString(var);
    for (const auto &subexpr : tableBuilder->getSubexprList())
        headers << QString::fromStdString(subexpr);
    ui->truthTable->setHorizontalHeaderLabels(headers);
    for (int i = 0; i < rows; ++i) {
        for (int j = 0; j < cols; ++j) {
            bool val = tableBuilder->value(i, j);
            ui->truthTable->setItem(i, j, new QTableWidgetItem(val ? "1" : "0"));
        }
    }




}

void MainWindow::on_clearButton_clicked()
{
    ui->inputLineEdit->clear();
    ui->inputLineEdit->setFocus();
    ui->truthTable->clearContents();
}
